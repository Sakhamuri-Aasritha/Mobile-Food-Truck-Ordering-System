import datetime

import os
import re

from flask import Flask, request, render_template, session, redirect
from bson import ObjectId
import pymongo
my_collections = pymongo.MongoClient("mongodb://localhost:27017/")
my_db = my_collections['MOBILE_FOOD_TRUCK_MANAGEMENT_SYSTEM']
admin_col = my_db['Admin']
food_truck_col = my_db['Food_Truck']
customer_col = my_db['Customer']
truck_timings_col = my_db['Truck_Timings']
category_col = my_db['Categories']
food_item_col = my_db['Food_Items']
customer_order_col = my_db['Customer_Orders']
customer_order_item_col = my_db['Customer_Order_Items']
review_col = my_db['Review']

if admin_col.count_documents({}) == 0:
    admin_col.insert_one({"username": "admin", "password": "admin", "role": "Admin"})

import random
from Mail import send_email

app = Flask(__name__)
app.secret_key = "lucky"
APP_ROOT = os.path.dirname(os.path.abspath(__file__))
APP_ROOT = APP_ROOT + "/static/"


@app.route("/")
def home():
    return render_template("home.html")


@app.route("/admin_login")
def admin_login():
    return render_template("admin_login.html")


@app.route("/admin_login1", methods=['post'])
def admin_login1():
    username = request.form.get("username")
    password = request.form.get("password")
    query = {"username": username, "password": password}
    admin = admin_col.find_one(query)

    if admin != None:
        session['admin_id'] = str(admin['_id'])
        session['role'] = 'Admin'
        return redirect("/admin_home")
    else:
        return render_template("msg.html", message="Invalid Login Details", color="text-danger")



@app.route("/admin_home")
def admin_home():
    return render_template("admin_home.html")


@app.route("/view_food_trucks")
def view_food_trucks():
    food_trucks = food_truck_col.find()
    return render_template("view_food_trucks.html", food_trucks=food_trucks)


@app.route("/view_customers")
def view_customers():
    customers = customer_col.find()
    return render_template("view_customers.html", customers=customers)


@app.route("/food_truck_registration")
def food_truck_registration():
    return render_template("food_truck_registration.html")


@app.route("/food_truck_registration_action", methods=['post'])
def food_truck_registration_action():
    food_truck_title = request.form.get("food_truck_title")
    name = request.form.get("name")
    email = request.form.get("email")
    password = request.form.get("password")
    confirm_password = request.form.get("confirm_password")
    phone = request.form.get("phone")
    address = request.form.get("address")
    query = {"email": email}
    count = food_truck_col.count_documents(query)
    if count > 0:
        return render_template("msg.html", message="duplicate email address")
    query = {"phone": phone}
    count = food_truck_col.count_documents(query)
    if count > 0:
        return render_template("msg.html", message="duplicate phone number")
    try:
        query = {"food_truck_title": food_truck_title, "name": name, "email": email,"password": password,"confirm_password":confirm_password, "phone": phone,"address":address}
        result = food_truck_col.insert_one(query)
        food_truck_id = result.inserted_id
        otp = random.randrange(1000, 100000)
        subject = "Food truck email verification"
        message = "use this OTP "+str(otp)+" to verify your account"
        print(otp)
        send_email(subject, message, email)
        return render_template("food_truck_verification.html", food_truck_id=food_truck_id, otp=otp)
    except Exception as e:
        print(e)
        return render_template("msg.html", message="something went wrong")


@app.route("/food_truck_verification", methods=['post'])
def food_truck_verification():
    food_truck_id = request.form.get("food_truck_id")
    query = {"_id": ObjectId(food_truck_id)}
    query2 = {"$set": {"verification_status": 'OTP verified'}}
    food_truck_col.update_one(query, query2)
    return render_template("msg.html", message="food registered successfully")


@app.route("/verify_food_truck")
def verify_food_truck():
    food_truck_id = request.args.get("food_truck_id")
    query = {"_id": ObjectId(food_truck_id)}
    query2 = {"$set": {"verification_status": 'Verified'}}
    food_truck_col.update_one(query, query2)
    return render_template("msg.html", message="food verified successfully")




@app.route("/food_truck_login")
def food_truck_login():
    return render_template("food_truck_login.html")


@app.route("/food_truck_login_action", methods=['post'])
def food_truck_login_action():
    email = request.form.get("email")
    password = request.form.get("password")
    query = {"email": email, "password": password}
    count = food_truck_col.count_documents(query)
    if count > 0:
        trucks = food_truck_col.find_one(query)
        if 'verification_status' in trucks and trucks['verification_status']=='Verified':
            session['food_truck_id'] = str(trucks['_id'])
            session['role'] = 'food_truck'
            return redirect("/food_truck_home")
        else:
            return render_template("notification.html", notification="Your Account Not Verified")
    else:
        return render_template("notification.html", notification="Invalid login Details")


@app.route("/food_truck_home")
def food_truck_home():
    food_truck_id = session['food_truck_id']
    query = {"_id": ObjectId(food_truck_id)}
    truck = food_truck_col.find_one(query)
    return render_template("food_truck_home.html", truck=truck)


@app.route("/add_truck_timings")
def add_truck_timings():
    truck = food_truck_col.find()
    return render_template("add_truck_timings.html", truck=truck,formate_time=formate_time)


@app.route("/add_truck_timings_action", methods=['post'])
def add_truck_timings_action():
    from_time = request.form.get("from_time")
    to_time = request.form.get("to_time")
    date = request.form.get("date")
    location = request.form.get("location")
    food_truck_id = ObjectId(session['food_truck_id'])
    from_time = date+" "+from_time
    to_time = date+" "+to_time

    from_time = datetime.datetime.strptime(from_time, '%Y-%m-%d %H:%M')
    to_time = datetime.datetime.strptime(to_time, '%Y-%m-%d %H:%M')

    query = {"$or": [
        {"from_time": {"$gte": from_time, "$lte": to_time}, "to_time": {"$gte": from_time, "$gte": to_time}, "food_truck_id": food_truck_id},
        {"from_time": {"$lte": from_time, "$lte": to_time}, "to_time": {"$gte": from_time, "$lte": to_time}, "food_truck_id": food_truck_id},
        {"from_time": {"$lte": from_time, "$lte": to_time}, "to_time": {"$gte": from_time, "$gte": to_time}, "food_truck_id": food_truck_id},
        {"from_time": {"$gte": from_time, "$lte": to_time}, "to_time": {"$gte": from_time, "$lte": to_time}, "food_truck_id": food_truck_id}]}
    count = truck_timings_col.count_documents(query)
    if count > 0:
        return {"message": "Time Collision"}
    else:
        query = {"from_time": from_time, "to_time": to_time, "date": date, "location": location, "food_truck_id": food_truck_id}
        truck_timings_col.insert_one(query)
        return {"message": "Timings Added Successfully"}


@app.route("/get_timings")
def get_timings():
    food_truck_id = session['food_truck_id']
    date = request.args.get("date")
    query = {"food_truck_id": ObjectId(food_truck_id), "date": date}
    timings = truck_timings_col.find(query)
    return render_template("view_truck_timings.html", timings=timings,formate_time= formate_time, str=str)


@app.route("/add_categories")
def add_categories():
    trucks = food_truck_col.find()
    return render_template("add_categories.html", trucks=trucks)


@app.route("/add_categories_action", methods=['post'])
def add_categories_action():
    category_name = request.form.get("category_name")
    food_truck_id = ObjectId(session['food_truck_id'])
    query = {"category_name": category_name, "food_truck_id": ObjectId(food_truck_id)}
    count = category_col.count_documents(query)
    if count > 0:
        return {"message": "Duplicate category name "}
    else:
        query = {"category_name": category_name, "food_truck_id": food_truck_id}
        category_col.insert_one(query)
        return {"message": "Category added successfully"}


@app.route("/get_categories")
def get_categories():
    food_truck_id = ObjectId(session['food_truck_id'])
    query = {"food_truck_id": food_truck_id}
    categories = category_col.find(query)
    return render_template("view_categories.html", categories=categories)


@app.route("/add_food_items")
def add_food_items():
    food_truck_id = ObjectId(session['food_truck_id'])
    query = {"food_truck_id": food_truck_id}
    categories = category_col.find(query)
    return render_template("add_food_items.html", categories=categories)


@app.route("/add_food_items_action", methods=['post'])
def add_food_items_action():
    food_item_name = request.form.get("food_item_name")
    price = request.form.get("price")
    quantity = request.form.get("quantity")
    units = request.form.get("units")
    category_id = request.form.get("category_id")
    picture = request.files.get("picture")
    description = request.form.get("description")
    query = {"food_item_name": food_item_name}
    count = food_item_col.count_documents(query)
    if count > 0:
        return render_template("fmsg.html", message="Food Item Name Is Already Exist")
    try:
        path = APP_ROOT +"/food_items/"+ picture.filename
        picture.save(path)
        print(path)
        query = {"food_item_name": food_item_name, "price": price, "quantity": quantity, "units": units, "category_id": ObjectId(category_id), "picture": picture.filename, "description": description, "status": 'Available'}
        food_item_col.insert_one(query)
        return render_template("fmsg.html", message="Food Item Added Successfully")
    except Exception as e:
        return render_template("fmsg.html", message="invalid Food Item Name")


@app.route("/search_by_food")
def search_by_food():
    return render_template("search_by_food.html")


@app.route("/get_food", methods=['get'])
def get_food():
    keyword = request.args.get("keyword")
    keyword2 = re.compile(".*" + keyword + ".*", re.IGNORECASE)
    query = {"category_name": keyword2}
    if session['role'] == 'food_truck':
        food_truck_id = ObjectId(session['food_truck_id'])
        query = {"food_truck_id": food_truck_id, "category_name": keyword2}
    print(query)
    categories = category_col.find(query)
    category_ids = []
    for category in categories:
        category_ids.append({"category_id": category['_id'],"food_item_name": keyword2})
    if len(category_ids) > 0:
        query = {"$or": category_ids}
    else:
        food_truck_id = ObjectId(session['food_truck_id'])
        query = {"food_truck_id": food_truck_id}
        categories = category_col.find(query)
        category_ids = []
        for category in categories:
            category_ids.append({"category_id": category['_id'], "food_item_name": keyword2})
        if len(category_ids) > 0:
            query = {"$or": category_ids}
        else:
            query = {"abc":"abc"}
    print(query)
    food_items = food_item_col.find(query)
    food_items = list(food_items)
    print(food_items)
    return render_template("view_food_items.html", food_items=food_items, get_categories_by_category_id=get_categories_by_category_id,get_food_truck_id_by_category_id=get_food_truck_id_by_category_id, get_food_trucks_by_food_truck_id=get_food_trucks_by_food_truck_id, get_truck_timings_by_food_truck_id=get_truck_timings_by_food_truck_id,get_rating_by_customer_order_item_id=get_rating_by_customer_order_item_id,get_customer_by_review_id=get_customer_by_review_id)


@app.route("/search_by_truck")
def search_by_truck():
    categories = category_col.find()
    food_trucks = food_truck_col.find()
    return render_template("search_by_truck.html", categories=categories, food_trucks=food_trucks)


@app.route("/get_food_by_truck_category_food_name", methods=['get'])
def get_food_by_truck_category_food_name():
    category_id = request.args.get("category_id")
    food_item_name = request.args.get("food_item_name")
    food_item_name1 = re.compile(".*" + food_item_name + ".*", re.IGNORECASE)
    query = {"category_id": ObjectId(category_id), "food_item_name": food_item_name1}
    food_items = food_item_col.find(query)
    return render_template("view_food_items.html", food_items=food_items, get_categories_by_category_id=get_categories_by_category_id,get_food_truck_id_by_category_id=get_food_truck_id_by_category_id, get_food_trucks_by_food_truck_id=get_food_trucks_by_food_truck_id, get_truck_timings_by_food_truck_id=get_truck_timings_by_food_truck_id,get_rating_by_customer_order_item_id=get_rating_by_customer_order_item_id,get_customer_by_review_id=get_customer_by_review_id)


@app.route("/get_categories_by_food_truck_id")
def get_categories_by_food_truck_id():
    food_truck_id = request.args.get("food_truck_id")
    query = {"food_truck_id": ObjectId(food_truck_id)}
    categories = category_col.find(query)
    return render_template("get_categories_by_food_truck_id.html", categories=categories)


@app.route("/get_food_by_location")
def get_food_by_location():
    query = {"from_time": {"$gt": datetime.datetime.now()}}
    truck_timings = truck_timings_col.find(query)
    locations = []
    for truck_timing in truck_timings:
        locations.append(truck_timing['location'])
    locations = set(locations)
    return render_template("get_food_by_location_datetime_food_name_category.html", locations=locations)

def get_categories_by_category_id(category_id):
    query = {"_id": ObjectId(category_id)}
    categories = category_col.find_one(query)
    return categories


def get_food_truck_id_by_category_id(category_id):
    query = {"_id": ObjectId(category_id)}
    categories = category_col.find_one(query)
    return categories


def get_food_trucks_by_food_truck_id(food_truck_id):
    query = {"_id": ObjectId(food_truck_id)}
    food_trucks = food_truck_col.find_one(query)
    return food_trucks


def get_truck_timings_by_food_truck_id(food_truck_id):
    query = {"food_truck_id": food_truck_id, "to_time": {"$gt": datetime.datetime.now()}}
    truck_timings = truck_timings_col.find(query)
    truck_timings = list(truck_timings)
    print(truck_timings)
    return truck_timings


@app.route("/customer_registration")
def customer_registration():
    return render_template("customer_registration.html")


@app.route("/customer_registration_action", methods=['post'])
def customer_registration_action():
    name = request.form.get("name")
    email = request.form.get("email")
    password = request.form.get("password")
    phone = request.form.get("phone")
    gender = request.form.get("gender")
    address = request.form.get("address")
    query = {"email": email}
    count = customer_col.count_documents(query)
    if count > 0:
        return render_template("msg.html", message="Duplicate email address")
    query = {"phone": phone}
    count = customer_col.count_documents(query)
    if count > 0:
        return render_template("msg.html", message="Duplicate phone number")
    try:
        query = {"name": name, "email": email, "password": password, "phone": phone, "gender": gender, "address": address}
        result = customer_col.insert_one(query)
        customer_id = result.inserted_id
        otp = random.randrange(1000, 100000)
        subject = "customer email verification"
        message = "use this OTP " + str(otp) + " to verify your account"
        print(otp)
        send_email(subject, message, email)
        return render_template("customer_verification.html", customer_id=customer_id, otp=otp)
    except Exception as e:
        return render_template("msg.html", message="Invalid login details")


@app.route("/customer_verification", methods=['post'])
def customer_verification():
    customer_id = request.form.get("customer_id")
    query = {"_id": ObjectId(customer_id)}
    query2 = {"$set": {"verification_status": 'verified'}}
    customer_col.update_one(query, query2)
    return render_template("msg.html", message="Customer Registered successfully")


@app.route("/customer_login")
def customer_login():
    return render_template("customer_login.html")


@app.route("/customer_login_action", methods=['post'])
def customer_login_action():
    email = request.form.get("email")
    password = request.form.get("password")
    query = {"email": email, "password": password}
    count = customer_col.count_documents(query)
    if count > 0:
        customers = customer_col.find_one(query)
        if 'verification_status' in customers and customers['verification_status'] == 'verified':
            session['customer_id'] = str(customers['_id'])
            session['role'] = 'customer'
            return redirect("/customer_home")
        else:
            return render_template("notification.html", notification="Your Account Not Verified")
    else:
        return render_template("notification.html", notification="Invalid login Details")


@app.route("/customer_home")
def customer_home():
    customer_id = session['customer_id']
    query = {"_id": ObjectId(customer_id)}
    customers = customer_col.find_one(query)
    return render_template("customer_home.html", customer=customers)


@app.route("/add_to_cart")
def add_to_cart():
    food_item_id = request.args.get("food_item_id")
    quantity = request.args.get("quantity")
    customer_id = session['customer_id']
    food_item = food_item_col.find_one({"_id": ObjectId(food_item_id)})
    category = category_col.find_one({"_id": food_item["category_id"]})
    food_truck_id = category['food_truck_id']
    query = {"customer_id": ObjectId(customer_id), "food_truck_id": food_truck_id, "status": "cart"}
    print(query)
    count = customer_order_col.count_documents(query)
    if count > 0:
        customer_order = customer_order_col.find_one(query)
        customer_order_id = customer_order['_id']
    else:
        query = {"customer_id": ObjectId(customer_id), "food_truck_id": food_truck_id, "status": "cart", "date": datetime.datetime.now()}
        result = customer_order_col.insert_one(query)
        customer_order_id = result.inserted_id
    query = {"food_item_id": ObjectId(food_item_id), "customer_order_id": ObjectId(customer_order_id)}
    count = customer_order_item_col.count_documents(query)
    if count > 0:
        customer_order_item = customer_order_item_col.find_one(query)
        query2 = {"$set": {"quantity": int(quantity)+int(customer_order_item['quantity'])}}
        customer_order_item_col.update_one(query, query2)
        return render_template("cmsg.html", message="food Item Updated successfully")
    else:
        query = {"food_item_id": ObjectId(food_item_id), "customer_order_id": ObjectId(customer_order_id), "quantity": quantity}
        customer_order_item_col.insert_one(query)
        return render_template("cmsg.html", message="food Item Add to Cart")


@app.route("/view_cart")
def view_cart():
    role = session['role']
    type = request.args.get("type")
    query = ""
    if role == 'customer':
         customer_id = session['customer_id']
         if type == 'cart':
             query = {"customer_id": ObjectId(customer_id), "status": "cart"}
         elif type == 'processing':
             query = {"$or":[{"customer_id": ObjectId(customer_id), "status": "ordered"},{"customer_id": ObjectId(customer_id), "status": "cooking"}, {"customer_id": ObjectId(customer_id), "status": "Ready for pickup"},{"customer_id": ObjectId(customer_id), "status": "Dispatched"}, {"customer_id": ObjectId(customer_id), "status": "Hand over to customer"}]}
         elif type == 'history':
             query = {"$or":[{"customer_id": ObjectId(customer_id), "status": "cancelled"},{"customer_id": ObjectId(customer_id), "status": "delivered"}]}
    elif role == 'food_truck':
        food_truck_id = session['food_truck_id']
        if type == 'ordered':
            query = {"food_truck_id": ObjectId(food_truck_id), "status": "ordered"}
        elif type == 'processing':
            query = {"$or": [{"food_truck_id": ObjectId(food_truck_id), "status": "cooking"},
                             {"food_truck_id": ObjectId(food_truck_id), "status": "Ready for pickup"},
                             {"food_truck_id": ObjectId(food_truck_id), "status": "Ready for picup"},
                             {"food_truck_id": ObjectId(food_truck_id), "status": "Dispatched"},
                             {"food_truck_id": ObjectId(food_truck_id), "status": "Hand over to customer"}]}

        elif type == 'history':
            query = {"$or": [{"food_truck_id": ObjectId(food_truck_id), "status": "cancelled"},
                             {"food_truck_id": ObjectId(food_truck_id), "status": "delivered"}]}
    customer_orders = customer_order_col.find(query)
    customer_orders = list(customer_orders)
    customer_orders.reverse()
    return render_template("view_cart.html", customer_orders=customer_orders, get_customer_by_customer_id=get_customer_by_customer_id,get_customer_order_items_by_customer_order_id=get_customer_order_items_by_customer_order_id, get_food_trucks_by_food_truck_id=get_food_trucks_by_food_truck_id,get_truck_timings_by_food_truck_id=get_truck_timings_by_food_truck_id, get_food_items_by_food_item_id=get_food_items_by_food_item_id, get_categories_by_category_id=get_categories_by_category_id, int=int, get_truck_timing_by_truck_timing_id=get_truck_timing_by_truck_timing_id,can_cook_the_order=can_cook_the_order,is_customer_is_not_reviews=is_customer_is_not_reviews)

# def get_food_truck_title_by_name()

def get_customer_by_customer_id(customer_id):
    query = {"_id": customer_id}
    customers = customer_col.find_one(query)
    return customers


def get_customer_order_items_by_customer_order_id(customer_order_id):
    query = {"customer_order_id": customer_order_id}
    customer_order_items = customer_order_item_col.find(query)
    return customer_order_items


def get_food_items_by_food_item_id(food_item_id):
    query = {"_id": food_item_id}
    food_items = food_item_col.find_one(query)
    return food_items


def get_truck_timing_by_truck_timing_id(truck_timing_id):
    query = {"_id": truck_timing_id}
    truck_timings = truck_timings_col.find_one(query)

    return truck_timings


def can_cook_the_order(truck_timing_id):
    query = {"_id": truck_timing_id}
    print(query)
    truck_timings = truck_timings_col.find_one(query)
    from_time = truck_timings['from_time']
    to_time = truck_timings['to_time']
    today = datetime.datetime.now()
    if today>=from_time and today<=to_time:
        return True
    return False


@app.route("/order_now")
def order_now():
    customer_order_id = request.args.get("customer_order_id")
    totalPrice = request.args.get("totalPrice")
    truck_timing_id = request.args.get("truck_timing_id")
    pick_up_time = request.args.get("pick_up_time")
    return render_template("order_now.html", customer_order_id=customer_order_id, totalPrice=totalPrice, truck_timing_id=truck_timing_id,pick_up_time=pick_up_time)


@app.route("/payment", methods=['post'])
def payment():
    customer_order_id = request.form.get("customer_order_id")
    truck_timing_id = request.form.get("truck_timing_id")
    pick_up_time = request.form.get("pick_up_time")
    query = {"_id": ObjectId(customer_order_id)}
    query2 = {"$set": {"status": 'ordered', "truck_timing_id": ObjectId(truck_timing_id), "pick_up_time": pick_up_time}}
    customer_order_col.update_one(query, query2)
    return render_template("cmsg.html", message="payment successfully")


@app.route("/set_status", methods=['post'])
def set_status():
    customer_order_id = request.form.get("customer_order_id")
    status = request.form.get("status")
    query = {"_id": ObjectId(customer_order_id)}
    query2 = {"$set": {"status": status}}
    customer_order_col.update_one(query, query2)
    return render_template("message.html", message="Order " +status+ " successfully ")


@app.route("/set_status2", methods=['post'])
def set_status2():
    customer_order_id = request.form.get("customer_order_id")
    status = request.form.get("status")
    query = {"_id": ObjectId(customer_order_id)}
    query2 = {"$set": {"status": status}}
    customer_order_col.update_one(query, query2)
    return render_template("message.html", message="order " +status+ " successfully")


@app.route("/remove_from_cart")
def remove_from_cart():
    customer_order_item_id = request.args.get("customer_order_item_id")
    query = {"_id": ObjectId(customer_order_item_id)}
    customer_order_items = customer_order_item_col.find_one(query)
    customer_order_id = customer_order_items['customer_order_id']
    query = {"_id": ObjectId(customer_order_item_id)}
    customer_order_item_col.delete_one(query)
    query = {"customer_order_id": ObjectId(customer_order_id)}
    count = customer_order_item_col.count_documents(query)
    if count > 0:
        return redirect("/view_cart?type=cart")
    else:
        query = {"_id": ObjectId(customer_order_id)}
        customer_order_col.delete_one(query)
        return render_template("cmsg.html", message="Item Removed successfully")


@app.route("/give_review")
def give_review():
    customer_order_item_id = request.args.get("customer_order_item_id")
    query = {"_id": ObjectId(customer_order_item_id)}
    customer_order_item = customer_order_item_col.find_one(query)
    return render_template("give_review.html", customer_order_items=customer_order_item, customer_order_item_id=customer_order_item_id)


@app.route("/give_review_action")
def give_review_action():
    customer_order_item_id = request.args.get("customer_order_item_id")
    review = request.args.get("review")
    rating = request.args.get("rating")
    query = {"review": review, "rating": rating, "customer_order_item_id": ObjectId(customer_order_item_id)}
    review_col.insert_one(query)
    return render_template("cmsg.html", message="Thank You For Your Review")


def get_rating_by_customer_order_item_id(food_item_id):
    query = {'food_item_id': ObjectId(food_item_id)}
    customer_order_items = customer_order_item_col.find(query)
    customer_order_item_ids = []
    for customer_order_item in customer_order_items:
        customer_order_item_ids.append({'customer_order_item_id': customer_order_item['_id']})
    if len(customer_order_item_ids) == 0:
        return 'No_Rating'
    query = {'$or': customer_order_item_ids}
    reviews = review_col.find(query)
    total_rating = 0
    number_of_ratings = 0
    for review in reviews:
        number_of_ratings = number_of_ratings + 1
        total_rating = total_rating + int(review['rating'])
    if number_of_ratings == 0:
        return 'No_Rating'
    rating = total_rating / number_of_ratings
    return rating


@app.route("/view_reviews")
def view_reviews():
    food_item_id = request.args.get("food_item_id")
    query = {"food_item_id": ObjectId(food_item_id)}
    customer_order_items = customer_order_item_col.find(query)
    customer_order_item_ids = []
    for customer_order_item in customer_order_items:
        customer_order_item_ids.append({"customer_order_item_id": ObjectId(customer_order_item['_id'])})
    if len(customer_order_item_ids) ==0:
        return render_template("fmsg.html",message="No Reviews")
    query = {"$or": customer_order_item_ids}
    reviews = review_col.find(query)
    reviews = list(reviews)
    if len(reviews)==0:
        return render_template("fmsg.html",message="No Reviews")
    return render_template("view_reviews.html", reviews=reviews, get_customer_by_review_id=get_customer_by_review_id,is_customer_is_not_reviews=is_customer_is_not_reviews)


def get_customer_by_review_id(review_id):
    query = {"_id": review_id}
    review = review_col.find_one(query)
    customer_order_item_id = review["customer_order_item_id"]
    query = {"_id": customer_order_item_id}
    customer_order_item = customer_order_item_col.find_one(query)
    customer_order_id = customer_order_item["customer_order_id"]
    query = {"_id": customer_order_id}
    customer_order = customer_order_col.find_one(query)
    customer_id = customer_order['customer_id']
    query = {"_id": customer_id}
    customer = customer_col.find_one(query)
    print(customer)
    return customer


def is_customer_is_not_reviews(customer_order_item_id):
    query = {'customer_order_item_id': ObjectId(customer_order_item_id)}
    count = review_col.count_documents(query)
    if count == 0:
        return True
    return False


@app.route("/logout")
def logout():
    session.clear()
    return redirect("/")

def formate_time(time):
    time = str(time.strftime("%I"))+":"+str(time.strftime("%M"))+" "+str(time.strftime("%p"))
    return time

app.run(debug=True)
